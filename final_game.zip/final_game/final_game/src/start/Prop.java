package start;

public class Prop {

}
