package start;

/**
 * Runs and holds all the objects and features to operate the game
 *
 */
public class GameManager {

	/**
	 * Constructor
	 */
	public GameManager() {
		
	}
}
