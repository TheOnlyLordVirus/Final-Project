package start;

public class Inventory {

}
