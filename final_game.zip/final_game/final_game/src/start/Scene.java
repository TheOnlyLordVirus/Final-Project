package start;

/**
 * Contains and manages the props within a certain enviroment
 *
 */
public class Scene {

}
