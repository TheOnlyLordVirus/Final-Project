package start;

public class books {
	private String bookname;
	
	public String getBookName () {
		return this.bookname;
	}
	
	public void setBookName(String BookName) {
		this.bookname = BookName;
	}
}
