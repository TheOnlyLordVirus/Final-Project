package start;

public interface SceneInterface 
{
	public String getName();
	public String getDescription();
	public void ParseCombination(String s);
	public void interaction();
}
